# BITSHIELD — deployable site

**Bitcoin Security & Payment Intelligence Platform**

This folder is the complete website. It is one file: `index.html` (7.29 MB) with all CSS,
JavaScript and the seven narrated lessons embedded. No build step, no server runtime, no
database, no environment variables.

```
index.html      the entire application
404.html        fallback page
robots.txt      allow all
netlify.toml    headers + publish settings (Netlify)
vercel.json     headers (Vercel)
.nojekyll       tells GitHub Pages to serve files as-is
```

## Run it locally

Option A — simplest: double-click `index.html`. It works from `file://`.

Option B — serve it like a real site:

```
cd bitshield-site
python3 -m http.server 8080
```

Then open http://localhost:8080/

## What is inside

13 views: Security Core, Operations Hub, Scam Risk Analyzer, Explorer & Verification,
Threat Universe, Evidence Map, Math Lab, Forensic Case Workspace, Video Tutorial Center,
Security Academy, Cyber Sentinel, Network Telemetry, Architecture & Integrity.

All analysis runs in the browser. The only outbound requests are the two optional public
blockchain lookups (mempool.space / blockstream.info), and they fire only when you press the
lookup button. Nothing is uploaded, no analytics, no fonts, no CDN.

## Accounts

**There is no login system in this build.** It was specified but not implemented, because a
real one needs a Supabase project, redirect URLs and OAuth credentials, and a frontend-only
"login" would be a simulation. `AUTH-SETUP.md` and `supabase/` in the project folder contain
the schema and setup notes for that stage; they are not wired into `index.html`.

## Deploy

See `DEPLOY.md` (3 platforms, 2 minutes each). Test checklist: `TESTING.md`.
