# Deploy BITSHIELD

The site is static. Any static host works. Pick one.

## GitHub Pages

1. Create a repository, e.g. `bitshield`.
2. Upload everything in this folder to the repository root (`index.html` must be at the root,
   not inside a subfolder). Keep `.nojekyll` — on some systems the file manager hides it, so
   use `git add .nojekyll` if you upload from a terminal.
3. Repository → **Settings → Pages** → Source: *Deploy from a branch* → Branch `main`,
   folder `/ (root)` → **Save**.
4. Wait ~1 minute. The address is `https://<username>.github.io/bitshield/`.

Note: the file is 7.3 MB. GitHub's web uploader accepts it, but a slow connection may time out;
`git push` is more reliable.

## Netlify

1. Go to app.netlify.com → **Add new site → Deploy manually**.
2. Drag this whole folder onto the drop area.
3. Done. `netlify.toml` sets the security headers and disables caching of `index.html`.
   You can rename the site under *Site configuration → Change site name*.

## Vercel

1. `npm i -g vercel` (one time), then inside this folder run `vercel`.
2. Accept the defaults: framework **Other**, root directory `.`, build command empty,
   output directory `.`.
3. `vercel --prod` for the public URL. `vercel.json` supplies the headers.

## Custom domain

Add the domain in the host's dashboard, then point a `CNAME` record at the host. Nothing in
the app depends on the hostname, so any domain works.

## What you do NOT need

- No Node build, no bundler, no API keys, no environment variables.
- No server, no database, no functions.
- No CORS configuration: the two optional lookups go to public APIs that allow browser calls.

## If you add accounts later

That changes the deployment: Supabase needs an `https` origin (not `file://`), redirect URLs
must be whitelisted in the dashboard, and the service-role key must never be placed in
`index.html`. See `AUTH-SETUP.md` in the project folder.
