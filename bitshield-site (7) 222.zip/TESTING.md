# Test the deployed site

Open the URL. Work down this list. Every item should behave as described; if one does not,
that is a real bug, not a design choice.

## First load
- [ ] Welcome overlay appears with the shield logo and **Start Investigation**.
- [ ] The theme toggle inside the overlay switches light/dark instantly.
- [ ] Reload: the chosen theme is remembered and the overlay stays dismissed.
- [ ] Browser devtools → Network: no requests to any third-party host on load.

## Navigation
- [ ] All 13 sidebar items open their view; the active item is highlighted.
- [ ] On the Security Core, the eight orbiting icons open their modules.
- [ ] Every view has breadcrumbs back to Security Core / Operations Hub.

## Scam Risk Analyzer
- [ ] Paste: `Pay a fee to unlock your withdrawal. Act now. Send your seed phrase.`
      → Analyze → band HIGH or CRITICAL, three findings listed, score ring filled.
- [ ] Press Analyze with an empty box → a clear "field is empty" message, no stale results.
- [ ] Add Photo with a small PNG → preview, size, "Not read automatically — no OCR".
      Type a description, Analyze → a **Preliminary review — screenshot not read** block.
- [ ] Add File with a `.txt` containing the sentence above → the filename appears in
      "Evidence analysed" and the band reacts to the file text.
- [ ] Try a 6 MB image and a `.exe` → both refused with a written reason.

## Explorer
- [ ] A valid address passes the local format check.
- [ ] A corrupted address fails with an explanation.
- [ ] "Check public blockchain" is a separate, deliberate click (and needs internet).

## Evidence Map
- [ ] With no cases: an empty-state sentence, no invented nodes.
- [ ] Create a case with an address and a message, then open the map → nodes appear.
- [ ] Drag pans, wheel zooms, Fit re-centres, search dims non-matches.
- [ ] Click a node → details show provenance, recorded time, verification, limits.
- [ ] Add a note, reload → the note is still there.
- [ ] Export report downloads a `.txt`; Snapshot downloads an `.svg` that opens in a browser.

## Math Lab
- [ ] Eight concepts in the pill row; each shows a diagram, a worked example and a limit.
- [ ] Risk panel lists eight rules with weights; ticking them updates the score and band.
- [ ] Toggle Forensic detail → formulas appear.

## Cases
- [ ] New case, add evidence, Save, reload → the case is still listed.
- [ ] Export TXT / JSON / HTML each download a file.

## Tutorials
- [ ] Seven lessons; the first is "Start here: rapid response".
- [ ] Play starts narration with captions; pause holds; step chips jump.
- [ ] Nothing autoplays on page load.

## Themes, mobile, keyboard
- [ ] Every view is readable in both themes (text never disappears into the background).
- [ ] At 375 px wide the sidebar becomes a drawer; no horizontal scrolling.
- [ ] Tab reaches every button; Enter activates; focus is always visible.

## Known limits (not bugs)
- One case and its map are stored per browser profile; clearing site data erases them.
- `localStorage` is not encrypted.
- No OCR, no PDF/DOCX reading, no account system, no cloud sync.
