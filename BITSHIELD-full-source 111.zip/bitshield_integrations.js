/* BITSHIELD optional integrations (Supabase + OpenAI proxy)
   Configure via window.BITSHIELD_CONFIG before this script, or leave empty for local-only. */
(function () {
  'use strict';

  var cfg = window.BITSHIELD_CONFIG || {};
  // Expected shape:
  // { supabaseUrl, supabaseAnonKey, enableCloudAI: false }

  function $(id) { return document.getElementById(id); }

  var state = {
    supabase: !!(cfg.supabaseUrl && cfg.supabaseAnonKey),
    server: false,
    openai: false,
    session: null // { access_token, user }
  };

  function headers(json, token) {
    var h = {};
    if (json) h['Content-Type'] = 'application/json';
    if (cfg.supabaseAnonKey) {
      h['apikey'] = cfg.supabaseAnonKey;
      h['Authorization'] = 'Bearer ' + (token || cfg.supabaseAnonKey);
    }
    return h;
  }

  async function probeServer() {
    try {
      var res = await fetch('/api/config', { credentials: 'include' });
      if (!res.ok) return;
      var d = await res.json();
      state.server = true;
      state.openai = !!d.openai;
      if (d.supabaseConfigured && !state.supabase) {
        /* server may hold URL for docs only; browser still needs anon key in BITSHIELD_CONFIG */
      }
      updateStatusBar();
    } catch (e) { /* local file mode */ }
  }

  function updateStatusBar() {
    var el = $('bsIntegrationsStatus');
    if (!el) return;
    var parts = [];
    parts.push('Chain: Blockstream/mempool (public)');
    parts.push(state.supabase ? 'Cases: Supabase (configured)' : 'Cases: localStorage');
    parts.push(state.server ? 'Auth server: on' : 'Auth server: off');
    parts.push(state.openai ? 'Cloud AI: available (consent required)' : 'Cloud AI: local guide only');
    el.textContent = parts.join(' · ');
  }

  /* ---- Supabase Auth (optional) ---- */
  async function sbSignUp(email, password, displayName) {
    if (!state.supabase) throw new Error('Supabase is not configured');
    var res = await fetch(cfg.supabaseUrl.replace(/\/$/, '') + '/auth/v1/signup', {
      method: 'POST',
      headers: headers(true),
      body: JSON.stringify({ email: email, password: password, data: { display_name: displayName || '' } })
    });
    var data = await res.json().catch(function () { return {}; });
    if (!res.ok) throw new Error(data.error_description || data.msg || data.error || 'Sign up failed');
    if (data.access_token) {
      state.session = { access_token: data.access_token, user: data.user };
      try { sessionStorage.setItem('bitshield_sb_token', data.access_token); } catch (e) {}
    }
    return data;
  }

  async function sbSignIn(email, password) {
    if (!state.supabase) throw new Error('Supabase is not configured');
    var res = await fetch(cfg.supabaseUrl.replace(/\/$/, '') + '/auth/v1/token?grant_type=password', {
      method: 'POST',
      headers: headers(true),
      body: JSON.stringify({ email: email, password: password })
    });
    var data = await res.json().catch(function () { return {}; });
    if (!res.ok) throw new Error(data.error_description || data.msg || data.error || 'Sign in failed');
    state.session = { access_token: data.access_token, user: data.user };
    try { sessionStorage.setItem('bitshield_sb_token', data.access_token); } catch (e) {}
    return data;
  }

  async function sbListCases() {
    var token = (state.session && state.session.access_token) || sessionStorage.getItem('bitshield_sb_token');
    if (!token) throw new Error('Not signed in to Supabase');
    var res = await fetch(cfg.supabaseUrl.replace(/\/$/, '') + '/rest/v1/cases?select=*&order=updated_at.desc', {
      headers: Object.assign(headers(false, token), { Prefer: 'return=representation' })
    });
    if (!res.ok) throw new Error('Could not load cases');
    return res.json();
  }

  async function sbCreateCase(title, notes) {
    var token = (state.session && state.session.access_token) || sessionStorage.getItem('bitshield_sb_token');
    if (!token) throw new Error('Not signed in to Supabase');
    var res = await fetch(cfg.supabaseUrl.replace(/\/$/, '') + '/rest/v1/cases', {
      method: 'POST',
      headers: Object.assign(headers(true, token), { Prefer: 'return=representation' }),
      body: JSON.stringify({ title: title || 'Untitled case', notes: notes || '' })
    });
    if (!res.ok) throw new Error('Could not create case');
    return res.json();
  }

  /* ---- Optional cloud AI with consent ---- */
  async function cloudAssist(message, page) {
    var consent = $('bsaCloudConsent');
    if (!consent || !consent.checked) {
      throw new Error('Enable “Allow cloud AI for this question” to use the optional server model.');
    }
    var res = await fetch('/api/ai/assist', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: message, page: page || '', consent: true })
    });
    var data = await res.json().catch(function () { return {}; });
    if (!res.ok) throw new Error(data.error || 'Cloud AI unavailable');
    return (data.reply || '') + (data.disclaimer ? '\n\n— ' + data.disclaimer : '');
  }

  function injectStatusBar() {
    if ($('bsIntegrationsStatus')) return;
    var bar = document.createElement('div');
    bar.id = 'bsIntegrationsStatus';
    bar.setAttribute('role', 'status');
    bar.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:400;max-width:min(520px,calc(100vw - 90px));padding:6px 10px;border-radius:8px;font-size:0.65rem;line-height:1.35;color:#94A3B8;background:rgba(7,12,34,0.85);border:1px solid rgba(138,158,210,0.2);pointer-events:none;';
    document.body.appendChild(bar);
    updateStatusBar();
  }

  function injectCloudConsent() {
    var chips = $('bsaChips');
    if (!chips || $('bsaCloudConsent')) return;
    var label = document.createElement('label');
    label.style.cssText = 'display:flex;align-items:flex-start;gap:6px;padding:0 14px 8px;font-size:0.7rem;color:#94A3B8;cursor:pointer;';
    label.innerHTML = '<input type="checkbox" id="bsaCloudConsent" style="margin-top:2px"> <span>Allow cloud AI for this question only (sends text to server if configured — not required for local answers)</span>';
    chips.parentNode.insertBefore(label, chips.nextSibling);
  }

  /* Hook assistant ask path when consent + server AI available */
  var tries = 0;
  function tryHookAssistant() {
    tries++;
    if (!window.BSAuth && tries < 20) {
      /* wait for other scripts */
    }
    injectCloudConsent();
    /* Enhance send: if consent checked, prefer cloud then fall back */
    var send = $('bsaSend');
    var input = $('bsaInput');
    if (send && !send.dataset.cloudHooked) {
      send.dataset.cloudHooked = '1';
      send.addEventListener('click', function () {
        var consent = $('bsaCloudConsent');
        if (!consent || !consent.checked) return; // local handler handles it
        /* local ask still runs; we intercept by temporarily replacing - skip to avoid double */
      }, true);
    }
  }

  window.BSIntegrations = {
    state: state,
    probe: probeServer,
    sbSignUp: sbSignUp,
    sbSignIn: sbSignIn,
    sbListCases: sbListCases,
    sbCreateCase: sbCreateCase,
    cloudAssist: cloudAssist,
    updateStatusBar: updateStatusBar,
    configured: function () {
      return { supabase: state.supabase, server: state.server, openai: state.openai };
    }
  };

  function init() {
    injectStatusBar();
    probeServer().then(function () {
      tryHookAssistant();
      updateStatusBar();
    });
    document.addEventListener('DOMContentLoaded', function () {
      injectStatusBar();
      tryHookAssistant();
    });
  }
  init();
})();
