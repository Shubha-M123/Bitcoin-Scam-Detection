'use strict';
/**
 * BITSHIELD auth server — zero npm dependencies (Node 18+).
 * scrypt password hashing + HMAC-SHA256 JWT + httpOnly cookie.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = Number(process.env.PORT) || 3001;
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const STATIC_ROOT = path.join(__dirname, '..');
const TOKEN_TTL_SEC = 7 * 24 * 60 * 60;

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, JSON.stringify({ users: [] }, null, 2));

function readUsers() {
  try {
    const d = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
    return Array.isArray(d.users) ? d : { users: [] };
  } catch {
    return { users: [] };
  }
}
function writeUsers(data) {
  const tmp = USERS_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, USERS_FILE);
}
function publicUser(u) {
  return { id: u.id, email: u.email, displayName: u.displayName, createdAt: u.createdAt };
}
function hashPassword(password, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}
function verifyPassword(password, salt, hash) {
  const h = crypto.scryptSync(password, salt, 64).toString('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(h, 'hex'), Buffer.from(hash, 'hex'));
  } catch {
    return false;
  }
}
function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
function signJwt(payload) {
  const header = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64url(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + TOKEN_TTL_SEC }));
  const sig = crypto.createHmac('sha256', JWT_SECRET).update(header + '.' + body).digest();
  return header + '.' + body + '.' + b64url(sig);
}
function verifyJwt(token) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [header, body, sig] = parts;
  const expected = b64url(crypto.createHmac('sha256', JWT_SECRET).update(header + '.' + body).digest());
  try {
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  } catch {
    return null;
  }
  try {
    const payload = JSON.parse(Buffer.from(body.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString());
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}
function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie || '';
  raw.split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function getToken(req) {
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) return auth.slice(7).trim();
  return parseCookies(req).bitshield_token || null;
}
function sendJson(res, status, obj, extraHeaders) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'X-Content-Type-Options': 'nosniff',
    ...(extraHeaders || {}),
  });
  res.end(body);
}
function setCors(req, res) {
  const origin = req.headers.origin || '*';
  res.setHeader('Access-Control-Allow-Origin', origin === 'null' ? 'null' : origin);
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,OPTIONS');
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > 64 * 1024) {
        reject(new Error('Body too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}
function cookieHeader(token, clear) {
  if (clear) return 'bitshield_token=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax';
  return 'bitshield_token=' + encodeURIComponent(token) + '; HttpOnly; Path=/; Max-Age=' + TOKEN_TTL_SEC + '; SameSite=Lax';
}
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};
function serveStatic(req, res, pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  rel = path.normalize(rel).replace(/^(\.\.[/\\])+/, '');
  const file = path.join(STATIC_ROOT, rel);
  if (!file.startsWith(STATIC_ROOT)) {
    res.writeHead(403); return res.end('Forbidden');
  }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': data.length,
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(data);
  });
}
const rateMap = new Map();
function rateLimit(ip) {
  const now = Date.now();
  const windowMs = 15 * 60 * 1000;
  let entry = rateMap.get(ip);
  if (!entry || now - entry.start > windowMs) {
    entry = { start: now, count: 0 };
    rateMap.set(ip, entry);
  }
  entry.count += 1;
  return entry.count <= 60;
}

async function handleApi(req, res, pathname) {
  setCors(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const ip = req.socket.remoteAddress || 'unknown';
  if (pathname.startsWith('/api/auth') && !rateLimit(ip)) {
    return sendJson(res, 429, { error: 'Too many attempts. Try again later.' });
  }
  if (pathname === '/api/health' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, service: 'bitshield-auth', time: new Date().toISOString() });
  }
  if (pathname === '/api/auth/register' && req.method === 'POST') {
    try {
      const body = await readBody(req);
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      const displayName = String(body.displayName || email.split('@')[0]).slice(0, 80);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return sendJson(res, 400, { error: 'Valid email is required' });
      if (password.length < 8) return sendJson(res, 400, { error: 'Password must be at least 8 characters' });
      const data = readUsers();
      if (data.users.some((u) => u.email === email)) return sendJson(res, 409, { error: 'An account with this email already exists' });
      const { salt, hash } = hashPassword(password);
      const user = { id: crypto.randomUUID(), email, displayName, salt, hash, createdAt: new Date().toISOString() };
      data.users.push(user);
      writeUsers(data);
      const pub = publicUser(user);
      const token = signJwt({ sub: user.id, email: user.email });
      return sendJson(res, 201, { user: pub, token, message: 'Account created' }, { 'Set-Cookie': cookieHeader(token) });
    } catch (e) {
      return sendJson(res, 400, { error: e.message || 'Could not create account' });
    }
  }
  if (pathname === '/api/auth/login' && req.method === 'POST') {
    try {
      const body = await readBody(req);
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      const data = readUsers();
      const user = data.users.find((u) => u.email === email);
      if (!user || !verifyPassword(password, user.salt, user.hash)) return sendJson(res, 401, { error: 'Invalid email or password' });
      const pub = publicUser(user);
      const token = signJwt({ sub: user.id, email: user.email });
      return sendJson(res, 200, { user: pub, token, message: 'Signed in' }, { 'Set-Cookie': cookieHeader(token) });
    } catch (e) {
      return sendJson(res, 400, { error: e.message || 'Could not sign in' });
    }
  }
  if (pathname === '/api/auth/logout' && req.method === 'POST') {
    return sendJson(res, 200, { message: 'Signed out' }, { 'Set-Cookie': cookieHeader('', true) });
  }
  if (pathname === '/api/auth/me' && req.method === 'GET') {
    const payload = verifyJwt(getToken(req));
    if (!payload) return sendJson(res, 401, { error: 'Authentication required' });
    const data = readUsers();
    const user = data.users.find((u) => u.id === payload.sub);
    if (!user) return sendJson(res, 401, { error: 'Session invalid' });
    return sendJson(res, 200, { user: publicUser(user) });
  }
  if (pathname === '/api/auth/me' && req.method === 'PATCH') {
    const payload = verifyJwt(getToken(req));
    if (!payload) return sendJson(res, 401, { error: 'Authentication required' });
    try {
      const body = await readBody(req);
      const displayName = String(body.displayName || '').trim().slice(0, 80);
      if (!displayName) return sendJson(res, 400, { error: 'displayName is required' });
      const data = readUsers();
      const idx = data.users.findIndex((u) => u.id === payload.sub);
      if (idx < 0) return sendJson(res, 404, { error: 'User not found' });
      data.users[idx].displayName = displayName;
      writeUsers(data);
      return sendJson(res, 200, { user: publicUser(data.users[idx]) });
    } catch (e) {
      return sendJson(res, 400, { error: e.message || 'Update failed' });
    }
  }

  if (pathname === '/api/config' && req.method === 'GET') {
    return sendJson(res, 200, {
      auth: true,
      openai: !!(process.env.OPENAI_API_KEY && String(process.env.OPENAI_API_KEY).length > 10),
      supabaseConfigured: !!(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY),
      bitcoin: { primary: 'blockstream.info (public)', fallback: 'mempool.space (public)' },
      note: 'Secrets never sent to the browser. openai true only means server key is present.'
    });
  }

  if (pathname === '/api/ai/assist' && req.method === 'POST') {
    const key = process.env.OPENAI_API_KEY;
    if (!key || String(key).length < 10) {
      return sendJson(res, 503, {
        error: 'OpenAI is not configured on the server. The local BITSHIELD Assistant still works offline.',
        localOnly: true
      });
    }
    try {
      const body = await readBody(req);
      if (!body || body.consent !== true) {
        return sendJson(res, 400, { error: 'Explicit consent is required before external AI processing.' });
      }
      const message = String(body.message || '').slice(0, 2000);
      const page = String(body.page || '').slice(0, 80);
      if (!message) return sendJson(res, 400, { error: 'message is required' });
      // Refuse seed-like payloads
      if (/\b([a-z]+(\s+[a-z]+){11,23})\b/i.test(message) && /seed|recovery|mnemonic/i.test(message)) {
        return sendJson(res, 400, { error: 'Do not send seed phrases or recovery words to any service.' });
      }
      const system =
        'You are BITSHIELD Assistant, a cautious Bitcoin security education helper. ' +
        'Distinguish general education from verified blockchain data. Never claim an address belongs to a person. ' +
        'Never invent transaction confirmations or balances. Risk scores are heuristics not proof of fraud. ' +
        'Current BITSHIELD page context: ' + (page || 'unknown') + '. Keep answers concise.';
      const payload = JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: message }
        ],
        temperature: 0.3,
        max_tokens: 500
      });
      const result = await new Promise((resolve, reject) => {
        const url = require('url').parse('https://api.openai.com/v1/chat/completions');
        const reqHttps = require('https').request({
          hostname: url.hostname,
          path: url.path,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + key,
            'Content-Length': Buffer.byteLength(payload)
          }
        }, (resp) => {
          const chunks = [];
          resp.on('data', (c) => chunks.push(c));
          resp.on('end', () => {
            const raw = Buffer.concat(chunks).toString('utf8');
            let data = {};
            try { data = JSON.parse(raw); } catch (e) {}
            resolve({ status: resp.statusCode, data });
          });
        });
        reqHttps.on('error', reject);
        reqHttps.write(payload);
        reqHttps.end();
      });
      if (result.status < 200 || result.status >= 300) {
        return sendJson(res, 502, { error: 'OpenAI request failed', detail: (result.data && result.data.error && result.data.error.message) || ('HTTP ' + result.status) });
      }
      const text = result.data && result.data.choices && result.data.choices[0] && result.data.choices[0].message
        ? result.data.choices[0].message.content
        : '';
      return sendJson(res, 200, {
        reply: text,
        source: 'openai',
        disclaimer: 'AI-generated explanation — not verified blockchain data or a fraud verdict.'
      });
    } catch (e) {
      return sendJson(res, 500, { error: e.message || 'AI assist failed' });
    }
  }

  return sendJson(res, 404, { error: 'Not found' });
}

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url || '/', 'http://' + (req.headers.host || 'localhost'));
    if (u.pathname.startsWith('/api/')) return await handleApi(req, res, u.pathname);
    return serveStatic(req, res, u.pathname);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) sendJson(res, 500, { error: 'Internal server error' });
  }
});

server.listen(PORT, () => {
  console.log('BITSHIELD auth server on http://localhost:' + PORT);
  console.log('Open http://localhost:' + PORT + '/index.html');
  console.log('Health http://localhost:' + PORT + '/api/health');
});
