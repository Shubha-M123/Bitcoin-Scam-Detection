# BITSHIELD setup (student-friendly)

## A. Local only (no account required)

1. Open `artifacts/index.html` in a browser, or:
2. `python3 -m http.server 8080` in the `artifacts` folder → http://localhost:8080

Features: Scam Risk Analyzer, Explorer (format + public Blockstream/mempool lookups), cases in localStorage, local Assistant.

## B. Optional auth server (Node, no npm required)

```bash
cd bitshield-server
PORT=3001 JWT_SECRET=your-long-random-secret node server-standalone.js
```

Open http://localhost:3001/index.html

- Register / Sign In against the local JSON user store (scrypt hashes)
- `/api/health` and `/api/config` for status
- Optional: set `OPENAI_API_KEY` in the environment for `/api/ai/assist` (consent required in the UI)

## C. Optional Supabase (multi-user cases)

1. Create a project at https://supabase.com
2. Run `supabase-schema.sql` in the SQL editor
3. Enable Email auth; add your site URL to redirect allow-list
4. In `index.html`, set:

```js
window.BITSHIELD_CONFIG = {
  supabaseUrl: 'https://YOUR_PROJECT.supabase.co',
  supabaseAnonKey: 'YOUR_ANON_KEY'
};
```

Never put the **service role** key in the browser.

5. Use Sign Up / Sign In once wired to Supabase helpers (`BSIntegrations.sbSignIn` / `sbSignUp`). Default welcome forms still support local demo + Node auth.

## D. Optional OpenAI

1. Run the Node server with `OPENAI_API_KEY` set (server environment only)
2. In the Assistant, check **Allow cloud AI for this question only**
3. Without consent or without a key, the **local** assistant answers

## E. Bitcoin lookups

Already use public Esplora-compatible APIs:

- Primary: https://blockstream.info/api
- Fallback: https://mempool.space/api

No API key required. User must click **Check public blockchain**.

## Security reminders

- localStorage is not encrypted
- Risk scores are heuristics, not proof of fraud
- Never paste seed phrases
- Do not treat addresses as identity
