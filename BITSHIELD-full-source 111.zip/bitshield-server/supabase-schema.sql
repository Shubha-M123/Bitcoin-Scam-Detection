-- BITSHIELD optional Supabase schema (run in Supabase SQL editor)
-- Requires: Authentication enabled (Email provider)

-- Profiles (optional display name)
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);
create policy "profiles_upsert_own" on public.profiles
  for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id);

-- Investigation cases (metadata + notes; keep large blobs local when possible)
create table if not exists public.cases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  title text not null default 'Untitled case',
  status text not null default 'open',
  notes text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists cases_user_id_idx on public.cases (user_id);

alter table public.cases enable row level security;

create policy "cases_select_own" on public.cases
  for select using (auth.uid() = user_id);
create policy "cases_insert_own" on public.cases
  for insert with check (auth.uid() = user_id);
create policy "cases_update_own" on public.cases
  for update using (auth.uid() = user_id);
create policy "cases_delete_own" on public.cases
  for delete using (auth.uid() = user_id);

-- Evidence metadata (text summaries; do not store seed phrases)
create table if not exists public.evidence_items (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.cases (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  kind text not null default 'note',
  label text default '',
  content_text text default '',
  created_at timestamptz not null default now()
);

create index if not exists evidence_user_id_idx on public.evidence_items (user_id);
create index if not exists evidence_case_id_idx on public.evidence_items (case_id);

alter table public.evidence_items enable row level security;

create policy "evidence_select_own" on public.evidence_items
  for select using (auth.uid() = user_id);
create policy "evidence_insert_own" on public.evidence_items
  for insert with check (auth.uid() = user_id);
create policy "evidence_update_own" on public.evidence_items
  for update using (auth.uid() = user_id);
create policy "evidence_delete_own" on public.evidence_items
  for delete using (auth.uid() = user_id);

-- Findings (rules / chain / user-labeled)
create table if not exists public.findings (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.cases (id) on delete cascade,
  user_id uuid not null references auth.users (id) on delete cascade,
  source text not null default 'user',
  summary text not null default '',
  payload jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.findings enable row level security;

create policy "findings_select_own" on public.findings
  for select using (auth.uid() = user_id);
create policy "findings_insert_own" on public.findings
  for insert with check (auth.uid() = user_id);
create policy "findings_update_own" on public.findings
  for update using (auth.uid() = user_id);
create policy "findings_delete_own" on public.findings
  for delete using (auth.uid() = user_id);
